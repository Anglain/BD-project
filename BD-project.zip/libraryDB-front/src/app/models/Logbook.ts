export class Logbook {
  Logbook_code: string;
  Lb_year: string;
}
