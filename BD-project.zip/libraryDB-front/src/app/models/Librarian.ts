export class Librarian {
  Tab_num: string;
  L_Surname: string;
  L_Name: string;
  L_Middle_name: string;
}
