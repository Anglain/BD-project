export class Book {
  UDK_cypher: string;
  BBK_cypher: string;
  Book_name: string;
  C_Category_name: string;
}
