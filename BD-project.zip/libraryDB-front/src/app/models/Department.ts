export class Department {
  Dep_name: string;
}
