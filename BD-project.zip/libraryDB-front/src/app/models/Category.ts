export class Category {
  Category_name: string;
}
