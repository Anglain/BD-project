export class Author {
  A_code: string;
  A_name: string;
  A_birth_date: string;
  Auth_nickname: string;
}
