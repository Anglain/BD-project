export class Reader {
  Reg_number: string;
  R_birth_date: string;
  Age_group: string;
  R_Surname: string;
  R_Name: string;
  R_Middle_name: string;
  Reg_date: string;
  Emails: [];
  PhoneNumbers: [];
}
