import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upper-bar',
  templateUrl: './upper-bar.component.html',
  styleUrls: ['./upper-bar.component.less']
})
export class UpperBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
