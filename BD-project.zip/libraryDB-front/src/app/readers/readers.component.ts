import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-readers',
  templateUrl: './readers.component.html',
  styleUrls: ['./readers.component.less']
})
export class ReadersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
