import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-librarians',
  templateUrl: './librarians.component.html',
  styleUrls: ['./librarians.component.less']
})
export class LibrariansComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
